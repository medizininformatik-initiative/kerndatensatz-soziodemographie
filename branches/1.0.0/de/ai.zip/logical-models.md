# Logical Models - v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts**](artifacts.md)
* **Logical Models**

## Logical Models

 Für die aktuelle Seite ist keine Übersetzung verfügbar, daher wurde sie in der Standardsprache dargestellt. 

### Logical Model

Logical models provide a conceptual view of the data structures defined in this implementation guide. They represent the data elements and their relationships independent of the FHIR resource structure.

* [Soziodemographie Logical Model](StructureDefinition-mii-lm-sdd.md) - Conceptual model for patient demographics, vital status, and identifying information

-------

For the corresponding FHIR resource profiles that implement these logical models, see [Profiles and Extensions](profiles-and-extensions.md).

