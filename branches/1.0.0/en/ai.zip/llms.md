# de.medizininformatikinitiative.kerndatensatz.soziodemographie#2027.0.0-ballot.rc1: MII Implementation Guide Soziodemographie(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Terminology](terminology.md)
* [Versioning](version-history.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Translation Information](translationinfo.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Guidance](guidance.md)
* [Downloads](downloads.md)
* [Security and Privacy](security-and-privacy.md)
* [Capability Statements](capability-statements.md)
* [UML Diagrams](uml-diagrams.md)

## Resources

### CodeSystems

* [MII CS SDD Ausbildung](CodeSystem-mii-cs-sdd-ausbildung.md)
* [MII CS SDD Berufliche Stellung (Langfversion)](CodeSystem-mii-cs-sdd-berufliche-stellung-lang.md)
* [MII CS SDD Berufliche Stellung (Minimalversion)](CodeSystem-mii-cs-sdd-berufliche-stellung-minimal.md)
* [MII CS SDD Beschaeftigungsstatus (Langfversion)](CodeSystem-mii-cs-sdd-beschaeftigungsstatus-lang.md)
* [MII CS SDD Beschaeftigungsstatus (Minimalversion)](CodeSystem-mii-cs-sdd-beschaeftigungsstatus-minimal.md)
* [MII CS SDD Betreuungssituation](CodeSystem-mii-cs-sdd-betreuungssituation.md)
* [MII CS SDD Einkommen](CodeSystem-mii-cs-sdd-einkommen.md)
* [MII CS SDD Erhebungsmethode](CodeSystem-mii-cs-sdd-erhebungsmethode.md)
* [MII CS SDD Laendercodes Sonder](CodeSystem-mii-cs-sdd-laendercodes-sonder.md)
* [MII CS SDD Merkzeichen (SGB IX / SchwbAwV)](CodeSystem-mii-cs-sdd-merkzeichen.md)
* [MII CS SDD Schulabschluss](CodeSystem-mii-cs-sdd-schulabschluss.md)
* [MII CS SDD Schwerbehindertenausweis](CodeSystem-mii-cs-sdd-schwerbehindertenausweis.md)

### ValueSets

* [MII VS SDD Ausbildung](ValueSet-mii-vs-sdd-ausbildung.md)
* [MII VS SDD Berufliche Stellung (Langversion)](ValueSet-mii-vs-sdd-berufliche-stellung-lang.md)
* [MII VS SDD Berufliche Stellung (Minimalversion)](ValueSet-mii-vs-sdd-berufliche-stellung-minimal.md)
* [MII VS SDD Beschaeftigungsstatus (Langversion)](ValueSet-mii-vs-sdd-beschaeftigungsstatus-lang.md)
* [MII VS SDD Beschaeftigungsstatus (Minimalversion)](ValueSet-mii-vs-sdd-beschaeftigungsstatus-minimal.md)
* [MII VS SDD Betreuungssituation](ValueSet-mii-vs-sdd-betreuungssituation.md)
* [MII VS SDD Einkommen](ValueSet-mii-vs-sdd-einkommen.md)
* [MII VS SDD Erhebungsmethode](ValueSet-mii-vs-sdd-erhebungsmethode.md)
* [MII VS SDD Laendercodes](ValueSet-mii-vs-sdd-laendercodes.md)
* [MII VS SDD Merkzeichen](ValueSet-mii-vs-sdd-merkzeichen.md)
* [MII VS SDD Schulabschluss](ValueSet-mii-vs-sdd-schulabschluss.md)

### Logicals

* [MII LM Soziodemographie](StructureDefinition-mii-lm-sdd.md)

### Resource Profiles

* [MII PR SDD Ausbildung](StructureDefinition-mii-pr-sdd-ausbildung.md)
* [MII PR SDD Berufliche Stellung](StructureDefinition-mii-pr-sdd-berufliche-stellung.md)
* [MII PR SDD Beschäftigungsstatus](StructureDefinition-mii-pr-sdd-beschaeftigungsstatus.md)
* [MII PR SDD Betreuungssituation](StructureDefinition-mii-pr-sdd-betreuungssituation.md)
* [MII PR SDD Datenerhebung](StructureDefinition-mii-pr-sdd-datenerhebung.md)
* [MII PR SDD Einkommen](StructureDefinition-mii-pr-sdd-einkommen.md)
* [MII PR SDD Geburtsland Mutter](StructureDefinition-mii-pr-sdd-geburtsland-mutter.md)
* [MII PR SDD Geburtsland Vater](StructureDefinition-mii-pr-sdd-geburtsland-vater.md)
* [MII PR SDD Haushaltsgroesse](StructureDefinition-mii-pr-sdd-haushaltsgroesse.md)
* [MII PR SDD Lebenssituation](StructureDefinition-mii-pr-sdd-lebenssituation.md)
* [MII PR SDD Partnerschaft](StructureDefinition-mii-pr-sdd-partnerschaft.md)
* [MII PR SDD Schulabschluss](StructureDefinition-mii-pr-sdd-schulabschluss.md)
* [MII PR SDD Schuljahre](StructureDefinition-mii-pr-sdd-schuljahre.md)
* [MII PR SDD Schwerbehindertenausweis](StructureDefinition-mii-pr-sdd-schwerbehindertenausweis.md)
* [MII PR SDD Soziooekonomische Faktoren](StructureDefinition-mii-pr-sdd-soziooekonomische-faktoren.md)
* [MII PR SDD Vertrauensperson](StructureDefinition-mii-pr-sdd-vertrauensperson.md)

### ImplementationGuides

* [MII Implementation Guide Soziodemographie](ImplementationGuide-mii-ig-soziodemographie.md)

### Examples

* [mii-exa-sdd-ausbildung (Observation)](Observation-mii-exa-sdd-ausbildung.md)
* [mii-exa-sdd-berufliche-stellung (Observation)](Observation-mii-exa-sdd-berufliche-stellung.md)
* [mii-exa-sdd-beschaeftigungsstatus (Observation)](Observation-mii-exa-sdd-beschaeftigungsstatus.md)
* [mii-exa-sdd-betreuungssituation (Observation)](Observation-mii-exa-sdd-betreuungssituation.md)
* [mii-exa-sdd-datenerhebung (Observation)](Observation-mii-exa-sdd-datenerhebung.md)
* [mii-exa-sdd-einkommen (Observation)](Observation-mii-exa-sdd-einkommen.md)
* [mii-exa-sdd-geburtsland-mutter (Observation)](Observation-mii-exa-sdd-geburtsland-mutter.md)
* [mii-exa-sdd-geburtsland-vater (Observation)](Observation-mii-exa-sdd-geburtsland-vater.md)
* [mii-exa-sdd-haushaltsgroesse (Observation)](Observation-mii-exa-sdd-haushaltsgroesse.md)
* [mii-exa-sdd-partnerschaft (Observation)](Observation-mii-exa-sdd-partnerschaft.md)
* [mii-exa-sdd-schulabschluss (Observation)](Observation-mii-exa-sdd-schulabschluss.md)
* [mii-exa-sdd-schuljahre (Observation)](Observation-mii-exa-sdd-schuljahre.md)
* [mii-exa-sdd-schwerbehindertenausweis (Observation)](Observation-mii-exa-sdd-schwerbehindertenausweis.md)
* [mii-exa-sdd-soziooekonomische-faktoren (Observation)](Observation-mii-exa-sdd-soziooekonomische-faktoren.md)
* [mii-exa-sdd-vertrauensperson (Observation)](Observation-mii-exa-sdd-vertrauensperson.md)
* [mii-exa-sdd-patient (Patient)](Patient-mii-exa-sdd-patient.md)
