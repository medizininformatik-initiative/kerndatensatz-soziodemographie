# MII VS SDD Erhebungsmethode - MII Implementation Guide Soziodemographie v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII VS SDD Erhebungsmethode**

## ValueSet: MII VS SDD Erhebungsmethode 

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-soziodemographie/ValueSet/mii-vs-sdd-erhebungsmethode | *Version*:2027.0.0-ballot |
| Draft Stand: 2026-11-02 | *Maschinenlesbarer Name*:MII_VS_SDD_Erhebungsmethode |

 
Value Set für Erhebungsmethode 

 **References** 

* [MII PR SDD Datenerhebung](StructureDefinition-mii-pr-sdd-datenerhebung.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-sdd-erhebungsmethode",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "url" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-soziodemographie/ValueSet/mii-vs-sdd-erhebungsmethode",
  "version" : "2027.0.0-ballot",
  "name" : "MII_VS_SDD_Erhebungsmethode",
  "title" : "MII VS SDD Erhebungsmethode",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-11-02T10:34:02+00:00",
  "publisher" : "NUM-DIZ",
  "contact" : [{
    "name" : "NUM-DIZ",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.netzwerk-universitaetsmedizin.de"
    }]
  }],
  "description" : "Value Set für Erhebungsmethode",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://www.medizininformatik-initiative.de/fhir/ext/modul-soziodemographie/CodeSystem/mii-cs-sdd-erhebungsmethode"
    }]
  }
}

```
