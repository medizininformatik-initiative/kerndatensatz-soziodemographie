# Changelog - MII Implementation Guide Soziodemographie v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Changelog**

## Changelog

### Changelog

This page records the changes between the released versions of the Soziodemographische Daten module, newest version first. It follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the KDS calendar versioning scheme described on the [Versioning](version-history.md) page.

-------

#### Version 2027.0.0-ballot

**Date:** 14.09.2026

#### Version 2027.0.0-ballot.rc1

**Date:** 31.08.2026

##### Added

* First publication of the Soziodemographie module.

