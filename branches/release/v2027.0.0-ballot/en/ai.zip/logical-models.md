# Logical Models - MII Implementation Guide Soziodemographie v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Logical Models**

## Logical Models

### Logical Model

Logical models provide a conceptual view of the data structures defined in this implementation guide. They represent the data elements and their relationships independent of the FHIR resource structure.

* [Soziodemographie Logical Model](StructureDefinition-mii-lm-sdd.md) - Conceptual model for patient demographics, vital status, and identifying information

-------

For the corresponding FHIR resource profiles that implement these logical models, see [Profiles](profiles.md).

